
import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import MainContent from "./components/MainContent/MainContent";
import Form from "./components/Form/Form";
import Courses from "./components/Courses/Courses";
import Toggle from "./components/Toggle/Toggle";


export default function Home() {
  return (
    
    <div>
      <Header />
      
      <main className="flex flex-col gap-8 row-start-2 items-center sm:items-start">
      <MainContent title = "COURSE TITLE: - Adv. Front-End Programming - CPAN-144-RNA"
      content = "STUDENT ID : Student_ID: N01717356"/>
      <br></br>

      <Toggle />

      <Courses />
      <Form />

      <br></br>

        <div className="flex gap-4 items-center flex-col sm:flex-row">
        
        </div>
      </main>
      <Footer />
    </div>
  );
}
