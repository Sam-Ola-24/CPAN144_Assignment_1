import "@/styles/globals.css";
import '../pages/components/Header/header.css';
import '../pages/index.css';
import '../pages/components/Footer/footer.css';
import '../pages/components/Form/form.css';
import '../pages/components/MainContent/maincontent.css';
import '../pages/components/Courses/courses.css';
import '../pages/components/Toggle/toggle.css';

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />;
}
