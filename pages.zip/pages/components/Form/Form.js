import React, { useState } from "react";

const Form = () => {
  const [input, setInput] = useState("");
  const [prompt, setPrompt] = useState("");

  const submitFunction = (event) => {
    event.preventDefault();
    if (!input) {
      setPrompt("Oops!...Something went wrong. Please enter your name!.");
    } else {
      setPrompt("Thank you! Your input has been submitted.");
    }
  };

  return (
    <div className="form">
      <form onSubmit={submitFunction}>
        <label>
          Thank you for visiting our page, please enter your name to qualify for
          a gift!!
        </label>
        <br></br>
        <input
          className="input-form"
          type="text"
          value={input}
          onChange={(event) => setInput(event.target.value)}
          style={{ color: "#000" }}
        />
        <br></br>
        <button className="b-form" type="submit">
          Submit
        </button>
      </form>

      {prompt}
    </div>
  );
};

export default Form;
