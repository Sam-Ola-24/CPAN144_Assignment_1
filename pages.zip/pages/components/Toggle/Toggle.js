import React, {useState} from 'react';

const Toggle = () => {
    //setting up the toggle functionality
    const [visible, setVisible] = useState(false);
   
return (
<div className="toggle">

<p></p>

<button onClick={() => setVisible(!visible)}> Click to see the current course code&nbsp;<br></br>

{visible ? 'Hide' : 'Show'}
<br></br>
{visible ? 'CPAN 144' : ''}
   
</button>
<br></br>
<br></br>

</div>
);
};

export default Toggle;