import React from 'react';


const Footer = () => {
return (
<footer>
<p>Sam Akinola - Assignment One</p>
</footer>

);
};

export default Footer;