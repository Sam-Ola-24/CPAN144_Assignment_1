import React, {useState} from 'react';


const Courses = () => {

  const [active, setActive] = useState("active");

    const courses = [
        {status:"active", name: "CPAN122"},
        {status:"inactive", name: "CPAN204"},
        {status:"active", name: "CPAN104"},
        {status:"inactive", name: "WRT120"},
        {status:"active", name: "CPAN212"},
        {status:"inactive", name: "CPAN312"},
        {status:"active", name: "CPAN100"},
    ];

    const groupCourses = courses.filter((course) => course.status === active );

return (
    <div className="courses">
        <h1 className="c-header">List of Courses</h1>
<button className="c-list" onClick={() => setActive("active")} > List only Active courses </ button>

<button className="c-list" onClick={() => setActive("inactive")} > List only Inactive courses </ button>
<br></br>

<ol>
    {groupCourses.map((course) => ( <li key={course.name}> {course.name} &nbsp; {course.status}</li>))}
</ol>

<br></br>

</div>

);
};

export default Courses;