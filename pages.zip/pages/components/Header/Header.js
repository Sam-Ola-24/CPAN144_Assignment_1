
import React, {useState} from 'react';

const Header = () => {

    const [hoverCount, setHoverCount] = useState(0);
  
        const handleMouseOver = () => {
            setHoverCount(hoverCount + 1);
        };
    
    
return (
<header>
<h1>Welcome to My React App</h1>
<p onMouseOver={handleMouseOver}>This is an introductory React app using components and props. <br></br>Hover here to see how the hover function updates {hoverCount} times</p>

</header>

);


};


export default Header;